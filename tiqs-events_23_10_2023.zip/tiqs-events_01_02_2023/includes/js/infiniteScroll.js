

(function () {

  // control variables
  let currentPage = 8;
  const limit = 2;

  const eventsEl = document.querySelector('#upcoming__events');
  const loaderEl = document.querySelector('.loader');

  // get the events from API
  const getEvents = async (page, limit) => {
      const API_URL = globalVariables.baseUrl + `Ajaxdorian/get_upcoming_events/?page=${page}&limit=${limit}`;
      const response = await fetch(API_URL);
      
      // handle 404
      if (!response.ok) {
          throw new Error(`An error occurred: ${response.status}`);
      }
      return await response.json();
  }

  const showLoader = () => {
      loaderEl.classList.add('show');
  };

  // load events
  const loadEvents = async (page, limit) => {

      // show the loader
      showLoader();

      // call the API to get events
      const response = await getEvents(page, limit);



      if(response.length == 0) {
        $('#stopInfiniteScroll').val('1');
        return ;
      }
      
      eventsEl.innerHTML += response;

  };

  
 
window.addEventListener("scroll", function() {
    let stopInfiniteScroll = $('#stopInfiniteScroll').val();
    
    if(stopInfiniteScroll == 1) {
        return ;
    }
    
    if(amountscrolled() >= 50) {
        currentPage += 2;
        loadEvents(currentPage, limit);
        
    }
}, false);

})();

function amountscrolled() {
    var winheight= window.innerHeight || (document.documentElement || document.body).clientHeight
    var docheight = $(document).height()
    var scrollTop = window.pageYOffset || (document.documentElement || document.body.parentNode || document.body).scrollTop
    var trackLength = docheight - winheight
    var pctScrolled = Math.floor(scrollTop/trackLength * 100) // gets percentage scrolled (ie: 80 or NaN if tracklength == 0)
    return pctScrolled;
}