<?php

namespace Tiqs_Events;

class EventsList
{
    public function __construct()
    {
        // Constructor logic
    }

    public function tiqs_events_list()
    {
        wp_enqueue_style('tiqs-events-admin', plugins_url('style-admin.css', __FILE__));
        wp_enqueue_style('tiqs-events-event-2', plugin_dir_url( __FILE__ ) . 'includes/css/events-list.css');
        wp_enqueue_script('tiqs-events-script-8', plugin_dir_url( __FILE__ ) . 'includes/js/custom.js');
        wp_localize_script('tiqs-events-script-8', 'data', array('ajaxurl' => admin_url('admin-ajax.php')));
        
        echo '<h1>Tiqs Events Info</h1>';
?>
        <form method="post" action="options.php">
            <?php settings_fields('tiqs-events-info-settings'); ?>
            <?php do_settings_sections('tiqs-events-info-settings'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Full Page Shortcode:</th>
                    <td>
                        [tiqs-events]
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Full Calendar Shortcode:</th>
                    <td>
                        [tiqs-event-calendar]
                    </td>
                    <th scope="row">Calendar Descript Shortcode:</th>
                    <td>
                        [tiqs-event-descript-calendar]
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Event Rows Shortcode:</th>
                    <td>
                        [tiqs-event-rows]
                    </td>
                    <th scope="row">Event Cards Shortcode:</th>
                    <td>
                        [tiqs-event-cards]
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Vendor Id:</th>
                    <td>
                        <input type="text" name="tiqs_events_info" value="<?php echo get_option('tiqs_events_info'); ?>" />
                    </td>
                    <th scope="row">Affiliate:</th>
                    <td>
                        <input type="text" name="tiqs_events_affiliate" value="<?php echo get_option('tiqs_events_affiliate'); ?>" />
                    </td>
                </tr>
                <tr valign="top">

                </tr>
            </table>

            <h1>Event Styles</h1>

            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Primary Color: <br>(R:242 G:30 B:78)</th>
                    <td>
                        <input type="color" name="tiqs_events_primary_color" value="<?php echo get_option('tiqs_events_primary_color') ? get_option('tiqs_events_primary_color') : '#f21e4e'; ?>" />
                    </td>
                    <th scope="row">Secondary Color: <br>(R:108 G:108 B:229)</th>
                    <td>
                        <input type="color" name="tiqs_events_secondary_color" value="<?php echo get_option('tiqs_events_secondary_color') ? get_option('tiqs_events_secondary_color') : '#6c6ce5'; ?>" />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Heading Color: <br>(R:69 G:67 B:96)</th>
                    <td>
                        <input type="color" name="tiqs_events_heading_color" value="<?php echo get_option('tiqs_events_heading_color') ? get_option('tiqs_events_heading_color') : '#454360'; ?>" />
                    </td>
                    <th scope="row">Font Color: <br>(R:94 G:92 B:122)</th>
                    <td>
                        <input type="color" name="tiqs_events_font_color" value="<?php echo get_option('tiqs_events_font_color') ? get_option('tiqs_events_font_color') : '#5E5C7F'; ?>" />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Radius Images:</th>
                    <td>
                        <input type="range" name="tiqs_events_radius_images" min="0" max="50" value="<?php echo (get_option('tiqs_events_radius_images') && get_option('tiqs_events_radius_images') !== 'true') ? get_option('tiqs_events_radius_images') : '10'; ?>" id="updateRadiusImages" />
                        <output id="updateRadiusImagesValue"><?php echo (get_option('tiqs_events_radius_images') && get_option('tiqs_events_radius_images') !== 'true') ? get_option('tiqs_events_radius_images') . 'px' : '10px'; ?></output>
                    </td>
                    <th scope="row">Radius Cards:</th>
                    <td>
                        <input type="range" name="tiqs_events_radius_cards" min="0" max="50" value="<?php echo (get_option('tiqs_events_radius_cards') && get_option('tiqs_events_radius_cards') != 'true') ? get_option('tiqs_events_radius_cards') : '20'; ?>" id="updateRadiusCards" />
                        <output id="updateRadiusCardsValue"><?php echo (get_option('tiqs_events_radius_cards') && get_option('tiqs_events_radius_cards') !== 'true') ? get_option('tiqs_events_radius_cards') . 'px' : '20px'; ?></output>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Show Full Width:</th>
                    <td>
                        <label class="switch">
                            <input type="checkbox" name="tiqs_events_full_width" <?php if (get_option('tiqs_events_full_width') === false || get_option('tiqs_events_full_width') == 'true') { ?> CHECKED <?php } ?> value="true" />
                            <span class="slider round"></span>
                        </label>
                    </td>
                </tr>
                <!-- <tr valign="top">
                <th scope="row">Show Event Details In Popup:</th>      
                <td>
                    <label class="switch">
                        <input type="checkbox" name="tiqs_events_popup_details" <?php if (get_option('tiqs_events_popup_details') === false || get_option('tiqs_events_popup_details') == 'true') { ?> CHECKED <?php } ?> value="true"/>
                        <span class="slider round"></span>
                    </label>
                </td>
            </tr> -->
            </table>

            <?php submit_button(); ?>
        </form>

        <div class="wrap">
            <h2>Tiqs Events</h2>
            <div class="tablenav top">
                <div class="alignleft actions">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=tiqs_events_create')); ?>">Add New Event</a>
                </div>
                <br class="clear">
            </div>
            <?php
            global $wpdb;
            $table_name = $wpdb->prefix . 'tiqs_events';

            $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE type = 'manual' AND vendorId = %s", get_option('tiqs_events_info')));

            $blockedApiEvents = $wpdb->get_results($wpdb->prepare("SELECT GROUP_CONCAT(event_id) AS 'eventId' FROM $table_name WHERE type = 'api' AND is_blocked = '1' AND vendorId = %s", get_option('tiqs_events_info')));
            $blockedApiEvents = isset($blockedApiEvents[0]->eventId) ? explode(',', $blockedApiEvents[0]->eventId) : array();

            $apiEventsUpdates = $wpdb->get_results($wpdb->prepare("SELECT event_id, vendorId, tag FROM $table_name WHERE type = 'api' AND tag != '' AND tag IS NOT NULL AND vendorId = %s", get_option('tiqs_events_info')));

            $events_plugin = new \Tiqs_Events\EventsPlugin();
            $apiRows = $events_plugin->get_api_events();

            ?>
            <table class="wp-list-table widefat fixed striped posts">
                <thead>
                    <tr>
                        <th class="manage-column ss-list-width">Name</th>

                        <th class="manage-column ss-list-width">Description</th>
                        <th class="manage-column ss-list-width">Tag</th>
                        <th class="manage-column ss-list-width">URL</th>
                        <th class="manage-column ss-list-width">Facebook Url</th>
                        <th class="manage-column ss-list-width">Category</th>
                        <th class="manage-column ss-list-width">Venue</th>

                        <th class="manage-column ss-list-width">Address</th>
                        <th class="manage-column ss-list-width">City</th>
                        <th class="manage-column ss-list-width">Zip Code</th>

                        <th class="manage-column ss-list-width">Country</th>
                        <th class="manage-column ss-list-width">Start Date</th>
                        <th class="manage-column ss-list-width">End Date</th>

                        <th class="manage-column ss-list-width">Start Time</th>
                        <th class="manage-column ss-list-width">End Time</th>
                        <th class="manage-column ss-list-width">Image</th>

                        <th class="manage-column ss-list-width">Type</th>
                        <th class="manage-column ss-list-width">Blocked</th>
                        <th class="manage-column ss-list-width">created At</th>
                        <th class="manage-column ss-list-width">Action</th>

                        <th>&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $row) { ?>
                        <tr>
                            <td class="manage-column ss-list-width"><?php echo $row->eventname; ?></td>

                            <td class="manage-column ss-list-width"><?php echo strlen($row->eventdescript) > 50 ? substr($row->eventdescript, 0, 30) . "..." : $row->eventdescript;; ?></td>
                            <td class="manage-column ss-list-width">
                                <div data-id="<?php echo $row->id ?>" data-vendor="<?php echo $row->vendorId ?>" data-type="<?php echo $row->type ?>"><input type="text" class="tag-input" value="<?php echo $row->tag ?>" /></div>
                            </td>
                            <td class="manage-column ss-list-width"><?php echo $row->url; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $row->facebookUrl ? $row->facebookUrl : '---'; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $row->eventCategory; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $row->eventVenue; ?></td>

                            <td class="manage-column ss-list-width"><?php echo $row->eventAddress; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $row->eventCity; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $row->eventZipcode; ?></td>

                            <td class="manage-column ss-list-width"><?php echo $row->eventCountry; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $row->StartDate; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $row->EndDate; ?></td>

                            <td class="manage-column ss-list-width"><?php echo $row->StartTime; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $row->EndTime; ?></td>
                            <td class="manage-column ss-list-width"><?php echo isset($row->eventImage) ? '<img src="' . $row->eventImage . '" width="100">' : '---'; ?></td>

                            <td class="manage-column ss-list-width"><?php echo $row->type; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $row->is_blocked ? 'Yes' : 'No'; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $row->createdAt; ?></td>

                            <td><a href="<?php echo admin_url('admin.php?page=tiqs_events_update&id=' . $row->id); ?>">Update</a> | <a href="<?php echo admin_url('admin.php?page=tiqs_events_block&type=manual&id=' . $row->id); ?>"><?php echo $row->is_blocked ? 'Un-Block' : 'Block'; ?></a></td>
                        </tr>
                    <?php } ?>

                    <?php foreach ($apiRows as $apiRow) {
                        $search = $apiRow->id;
                        $isDataExist = array_filter($apiEventsUpdates, function ($item) use ($search) {
                            return $item->event_id == $search;
                        });

                        $tag = isset($isDataExist[array_key_first($isDataExist)]->tag) ? $isDataExist[array_key_first($isDataExist)]->tag : '';
                    ?>
                        <tr>
                            <!-- <td class="manage-column ss-list-width"><?php // echo $apiRow->vendorId; 
                                                                            ?></td> -->
                            <td class="manage-column ss-list-width"><?php echo $apiRow->eventname; ?></td>

                            <td class="manage-column ss-list-width"><?php echo strlen($apiRow->eventdescript) > 50 ? substr(htmlspecialchars($apiRow->eventdescript), 0, 30) . "..." : $apiRow->eventdescript; ?></td>
                            <td class="manage-column ss-list-width">
                                <div data-id="<?php echo $apiRow->id ?>" data-vendor="<?php echo $apiRow->vendorId ?>" data-type="<?php echo 'api' ?>"><input type="text" class="tag-input" value="<?php echo $tag ?>" /></div>
                            </td>
                            <td class="manage-column ss-list-width">---</td>
                            <td class="manage-column ss-list-width"><?php echo $apiRow->facebookUrl ? $apiRow->facebookUrl : '---'; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $apiRow->eventCategory; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $apiRow->eventVenue; ?></td>

                            <td class="manage-column ss-list-width"><?php echo $apiRow->eventAddress; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $apiRow->eventCity; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $apiRow->eventZipcode; ?></td>

                            <td class="manage-column ss-list-width"><?php echo $apiRow->eventCountry; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $apiRow->StartDate; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $apiRow->EndDate; ?></td>

                            <td class="manage-column ss-list-width"><?php echo $apiRow->StartTime; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $apiRow->EndTime; ?></td>
                            <td class="manage-column ss-list-width"><?php echo (isset($apiRow->eventImage) && $apiRow->eventImage) ? ('<img width="100" src="https://tiqs.com/alfred/assets/images/events/' . $apiRow->eventImage . '">') : '---'; ?></td>

                            <td class="manage-column ss-list-width">api</td>
                            <td class="manage-column ss-list-width"><?php echo in_array($apiRow->id, $blockedApiEvents) ? 'Yes' : 'No'; ?></td>
                            <td class="manage-column ss-list-width"><?php echo $apiRow->createdAt; ?></td>

                            <td><a href="<?php echo admin_url('admin.php?page=tiqs_events_block&type=api&id=' . $apiRow->id . '&vendorId=' . $apiRow->vendorId); ?>"><?php echo in_array($apiRow->id, $blockedApiEvents) ? 'Un-Block' : 'Block'; ?></a></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
<?php
    }

    public function get_page_url($path = '')
    {
        $url = plugins_url($path, __FILE__);

        if (is_ssl() && 'http:' === substr($url, 0, 5)) {
            $url = 'https:' . substr($url, 5);
        }

        return $url;
    }
}
