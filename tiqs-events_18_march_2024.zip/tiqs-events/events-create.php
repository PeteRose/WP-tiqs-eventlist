<?php

function tiqs_events_create() {
    $vendorId       = isset($_POST["vendorId"])         ? $_POST["vendorId"]        : '';
    $eventname      = isset($_POST["eventname"])        ? $_POST["eventname"]       : '';
    $eventdescript  = isset($_POST["eventdescript"])    ? $_POST["eventdescript"]   : '';

    $eventCategory  = isset($_POST["eventCategory"])    ? $_POST["eventCategory"]   : '';
    $eventVenue     = isset($_POST["eventVenue"])       ? $_POST["eventVenue"]      : '';
    $eventAddress   = isset($_POST["eventAddress"])     ? $_POST["eventAddress"]    : '';
    
    $eventCity      = isset($_POST["eventCity"])        ? $_POST["eventCity"]       : '';
    $eventZipcode   = isset($_POST["eventZipcode"])     ? $_POST["eventZipcode"]    : '';
    $eventCountry   = isset($_POST["eventCountry"])     ? $_POST["eventCountry"]    : '';

    $StartDate      = isset($_POST["StartDate"])        ? $_POST["StartDate"]       : '';
    $EndDate        = isset($_POST["EndDate"])          ? $_POST["EndDate"]         : '';
    $StartTime      = isset($_POST["StartTime"])        ? $_POST["StartTime"]       : '';

    $EndTime        = isset($_POST["EndTime"])          ? $_POST["EndTime"]         : '';
    $url            = isset($_POST["url"])              ? $_POST["url"]             : '';
    $facebookUrl    = isset($_POST["facebookUrl"])      ? $_POST["facebookUrl"]     : '';


    //insert
    if (isset($_POST['insert'])) {
        

        global $wpdb;
        $table_name = $wpdb->prefix . "tiqs_events";

        $upload = wp_handle_upload( 
            $_FILES[ 'eventImage' ], 
            array( 'test_form' => false ) 
        );

        $wpdb->insert(
                $table_name, //table
                array(
                    'vendorId'      => $vendorId, 
                    'eventname'     => $eventname,
                    'eventdescript' => $eventdescript,

                    'eventCategory' => $eventCategory,
                    'eventVenue'    => $eventVenue,
                    'eventAddress'  => $eventAddress,

                    'eventCity'     => $eventCity,
                    'eventZipcode'  => $eventZipcode,
                    'eventCountry'  => $eventCountry,

                    'StartDate'     => date("Y-m-d", strtotime($StartDate)),
                    'EndDate'       => date("Y-m-d", strtotime($EndDate)),
                    'StartTime'     => date("H:i:s", strtotime($StartTime)),

                    'EndTime'       => date("H:i:s", strtotime($EndTime)),
                    'eventImage'    => $upload['url'],
                    'url'           => $url,
                    'facebookUrl'   => $facebookUrl,
                    'createdAt'     => date("Y-m-d H:i:s"),
                    'updatedAt'     => date("Y-m-d H:i:s"),

                ), //data		
        );
        $message ="Event insert successfully.";
    }
    ?>
    <link type="text/css" href="<?php echo WP_PLUGIN_URL; ?>/tiqs-events/style-admin.css" rel="stylesheet" />
    <div class="wrap">
        <h2>Add New Event</h2>
        <?php if (isset($message)): ?>
            <div class="updated">
                <p><?= $message; ?></p>
            </div>
            <a href="<?php echo admin_url('admin.php?page=tiqs_events_list') ?>">&laquo; Back to events list</a>
        <?php exit; endif; ?>
        <form method="post" enctype="multipart/form-data" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
            <table class='wp-list-table widefat fixed'>
                <tr>
                    <th class="ss-th-width">Vendor Id</th>
                    <td>
                        <input type="text" name="vendorId" value="<?= $vendorId; ?>" class="ss-field-width" placeholder="Vendor Id" required />
                    </td>
                    <th class="ss-th-width">Event Name</th>
                    <td>
                        <input type="text" name="eventname" value="<?= $eventname; ?>" class="ss-field-width" placeholder="Event Name" required />
                    </td>
                </tr>
                <tr>
                    <th class="ss-th-width">Event Description</th>
                    <td>
                        <input type="text" name="eventdescript" value="<?= $eventdescript; ?>" class="ss-field-width" placeholder="Description" required />
                    </td>
                    <th class="ss-th-width">Event Category</th>
                    <td>
                        <input type="text" name="eventCategory" value="<?= $eventCategory; ?>" class="ss-field-width" placeholder="Category" required />
                    </td>
                </tr>
                <tr>
                    <th class="ss-th-width">Event Venue</th>
                    <td><input type="text" name="eventVenue" value="<?= $eventVenue; ?>" class="ss-field-width" placeholder="Venue" required /></td>
                    <th class="ss-th-width">Event Address</th>
                    <td><input type="text" name="eventAddress" value="<?= $eventAddress; ?>" class="ss-field-width" placeholder="Address" required /></td>
                </tr>


                <tr>
                    <th class="ss-th-width">Event City</th>
                    <td><input type="text" name="eventCity" value="<?= $eventCity; ?>" class="ss-field-width" placeholder="City" required /></td>
                    <th class="ss-th-width">Event Zip Code</th>
                    <td><input type="text" name="eventZipcode" value="<?= $eventZipcode; ?>" class="ss-field-width" placeholder="Zip Code" required /></td>
                </tr>
                <tr>
                    <th class="ss-th-width">Event Country</th>
                    <td><input type="text" name="eventCountry" value="<?= $eventCountry; ?>" class="ss-field-width" placeholder="Country" required /></td>
                    <th class="ss-th-width">Start Date</th>
                    <td><input type="date" name="StartDate" value="<?= $StartDate; ?>" class="ss-field-width" placeholder="Start Date" required /></td>
                </tr>

                <tr>
                    <th class="ss-th-width">End Date</th>
                    <td><input type="date" name="EndDate" value="<?= $EndDate; ?>" class="ss-field-width" placeholder="End Date" required /></td>
                    <th class="ss-th-width">Start Time</th>
                    <td><input type="time" name="StartTime" value="<?= $StartTime; ?>" class="ss-field-width" placeholder="Start Time" required /></td>
                </tr>



                <tr>
                    <th class="ss-th-width">End Time</th>
                    <td><input type="time" name="EndTime" value="<?= $EndTime; ?>" class="ss-field-width" placeholder="End Time" /></td>
                    <th class="ss-th-width">Event Image</th>
                    <td><input type="file" accept="image/jpg, image/jpeg, image/png" name="eventImage" class="ss-field-width" placeholder="Image" /></td>
                </tr>

                <tr>
                    <th class="ss-th-width">URL</th>
                    <td><input type="url" name="url" value="<?= $url; ?>" class="ss-field-width" placeholder="URL" /></td>
                    <th class="ss-th-width">Facebook Url</th>
                    <td><input type="url" name="facebookUrl" value="<?= $facebookUrl; ?>" class="ss-field-width" placeholder="Facebook Url" /></td>
                </tr>

            </table>
            <br>
            <input type='submit' name="insert" value='Save' class='button'>
        </form>
    </div>
    <?php
}