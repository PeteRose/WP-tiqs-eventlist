=== Oldskoolbelgium Events ===
Contributors: (this should be a list of wordpress.org userid's)
Tags: oldskool, belgium, Oldskoolbelgium
Requires PHP: 7.4
License: GPLv2 or later
This Plugin is for Oldskoolbelgium Events.