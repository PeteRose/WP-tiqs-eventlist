var closeIcons = document.getElementsByClassName("tag-input");

function update_tags() {
  var ajaxData = {
    action: "update_status_db",
    id: jQuery(this).parent().data("id"),
    vendorId: jQuery(this).parent().data("vendor"),
    type: jQuery(this).parent().data("type"),
    tag: jQuery(this).val().trim(),
  };

  // console.log("ASDASDA", ajaxData)

  jQuery.ajax({
    type: "POST",
    url: data.ajaxurl,
    data: ajaxData,
    success: function (response) {
      console.log("Data returned: " + response);
    },
    error: function () {
      alert("FAILED TO POST DATA!!");
    },
  });
}

for (i = 0; i < closeIcons.length; i++) {
  closeIcons[i].addEventListener("input", update_tags);
}

document.getElementById("updateRadiusImages").addEventListener("change", updateRadiusImages);
function updateRadiusImages(e) {
  document.getElementById('updateRadiusImagesValue').value = e.target.value + 'px'; 
}

document.getElementById("updateRadiusCards").addEventListener("change", updateRadiusCards);
function updateRadiusCards(e) {
  document.getElementById('updateRadiusCardsValue').value = e.target.value + 'px'; 
}