<?php
/* 

Plugin name: Tiqs Events 
Description: Display Tiqs Events 
Author: Tiqs 
Version: 1.0.4 
*/

namespace Tiqs_Events;

class EventsPlugin
{
	public function __construct()
	{
		// run the install scripts upon plugin activation
		register_activation_hook(__FILE__, array($this, 'ss_options_install'));

		// Add menu items and callbacks
		add_action('admin_menu', array($this, 'tiqs_events_modifymenu'));

		// Register plugin settings in the database
		add_action('admin_init', array($this, 'update_tiqs_events_info'));

		add_shortcode('tiqs-events', array($this, 'tiqs_events_info_short_code'));
		add_shortcode('tiqs-event-calendar', array($this, 'tiqs_event_calendar'));
		add_shortcode('tiqs-event-rows', array($this, 'tiqs_event_rows'));
		add_shortcode('tiqs-event-cards', array($this, 'tiqs_event_cards'));
		add_shortcode('tiqs-event-descript-calendar', array($this, 'tiqs_event_descript_calendar'));

		// Add custom query var
        add_filter('query_vars', array($this, 'add_custom_query_var'));

		// Add plugin hooks and shortcodes
        add_action('wp_head', array('\Tiqs_Events\EventsFrontSide', 'tiqs_events_header'));
		// add_action('wp_footer', array('\Tiqs_Events\EventsFrontSide', 'tiqs_events_footer_js'));
		
		add_action('wp_ajax_update_status_db', array('\Tiqs_Events\UpdateEventTags', 'toed_update_status_db_callback'));

		if (!defined('TOED_EVENTROOTDIR')) {
            define('TOED_EVENTROOTDIR', plugin_dir_path(__FILE__));
        }

		// Include necessary files
        $this->include_files();

	}

	public function ss_options_install()
	{
		global $wpdb;

		$table_name = $wpdb->prefix . "tiqs_events";
		$charset_collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE $table_name (
			`id` bigint NOT NULL AUTO_INCREMENT PRIMARY KEY,
			`event_id` int(11) NULL,
			`vendorId` int(11) NOT NULL,
			`eventname` varchar(255) CHARACTER SET utf8 NULL,
			`eventdescript` longtext CHARACTER SET utf8 NULL,
			`eventCategory` varchar(255) CHARACTER SET utf8 NULL,
			`eventVenue` varchar(255) CHARACTER SET utf8 NULL,
			`eventAddress` varchar(255) CHARACTER SET utf8 NULL,
			`eventCity` varchar(255) CHARACTER SET utf8 NULL,
			`eventZipcode` varchar(255) CHARACTER SET utf8 NULL,
			`eventCountry` varchar(255) CHARACTER SET utf8 NULL,
			`StartDate` date NULL,
			`EndDate` date NULL,
			`StartTime` time NULL,
			`EndTime` time NULL,
			`eventImage` varchar(255) CHARACTER SET utf8 NULL,
			`tag` varchar(255) CHARACTER SET utf8 NULL,
			`url` varchar(255) CHARACTER SET utf8 NULL,
			`facebookUrl` varchar(255) CHARACTER SET utf8 NULL,
			`type` enum('api','manual') CHARACTER SET utf8 NULL DEFAULT 'manual',
			`is_blocked` enum('0','1') CHARACTER SET utf8 NULL DEFAULT '0',
			`createdAt` timestamp NULL,
			`updatedAt` timestamp NULL
		  ) $charset_collate; ";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta($sql);
	}

	public function tiqs_events_modifymenu()
	{
		//this is the main item for the menu
		add_menu_page(
			'Tiqs Events', //page title
			'Tiqs Events', //menu title
			'manage_options', //capabilities
			'tiqs_events_list', //menu slug
			function () {
				$events_list = new \Tiqs_Events\EventsList();
				$events_list->tiqs_events_list();
			} // Updated callback
		);

		//this is a submenu
		add_submenu_page(
			'tiqs_events_list', //parent slug
			'Add New Event', //page title
			'Add New', //menu title
			'manage_options', //capability
			'tiqs_events_create', //menu slug
			function () {
				$events_create = new \Tiqs_Events\EventsCreate();
				$events_create->tiqs_events_create();
			} // Updated callback
		); //function

		//this submenu is HIDDEN, however, we need to add it anyways
		add_submenu_page(
			null, //parent slug
			'Update Event', //page title
			'Update', //menu title
			'manage_options', //capability
			'tiqs_events_update', //menu slug
			function () {
				$events_update = new \Tiqs_Events\EventsUpdate();
				$events_update->tiqs_events_update();
			} // Updated callback
		); //function

		//this submenu is HIDDEN, however, we need to add it anyways
		add_submenu_page(
			null, //parent slug
			'Block Event', //page title
			'Block', //menu title
			'manage_options', //capability
			'tiqs_events_block', //menu slug
			function () {
				$events_block = new \Tiqs_Events\EventsBlock();
				$events_block->tiqs_events_block();
			} // Updated callback
		); //function
	}

	public function update_tiqs_events_info()
	{
		register_setting('tiqs-events-info-settings', 'tiqs_events_info');
		register_setting('tiqs-events-info-settings', 'tiqs_events_affiliate');
		// register_setting( 'tiqs-events-info-settings', 'tiqs_events_font_size' ); 
		register_setting('tiqs-events-info-settings', 'tiqs_events_primary_color');
		register_setting('tiqs-events-info-settings', 'tiqs_events_secondary_color');
		register_setting('tiqs-events-info-settings', 'tiqs_events_heading_color');
		register_setting('tiqs-events-info-settings', 'tiqs_events_font_color');
		register_setting('tiqs-events-info-settings', 'tiqs_events_radius_images');
		register_setting('tiqs-events-info-settings', 'tiqs_events_radius_cards');
		register_setting('tiqs-events-info-settings', 'tiqs_events_popup_details');
		register_setting('tiqs-events-info-settings', 'tiqs_events_full_width');
	}

	public function tiqs_events_info($content)
	{
		$extra_info = get_option('tiqs_events_info');
		return $content . $extra_info;
	}

	public function tiqs_events_info_short_code($atts)
	{
		// Shortcode logic here
		$events_front_side = new \Tiqs_Events\EventsFrontSide();
		return $events_front_side->tiqs_events_info_short_code();
	}

	public function tiqs_event_calendar($atts)
	{
		// Shortcode logic here
		$events_front_side = new \Tiqs_Events\EventsFrontSide();
		return $events_front_side->tiqs_events_info_short_code();
	}

	public function tiqs_event_rows($atts)
	{
		// Shortcode logic here
		$events_front_side = new \Tiqs_Events\EventsFrontSide();
		return $events_front_side->tiqs_events_info_short_code();
	}

	public function tiqs_event_cards($atts)
	{
		// Shortcode logic here
		$events_front_side = new \Tiqs_Events\EventsFrontSide();
		return $events_front_side->tiqs_events_info_short_code();
	}

	public function tiqs_event_descript_calendar($atts)
	{
		// Shortcode logic here
		$events_front_side = new \Tiqs_Events\EventsFrontSide();
		return $events_front_side->tiqs_events_info_short_code();
	}

	public function get_api_events() {
		$extra_info = get_option('tiqs_events_info');
		$data = array('vendorId' => $extra_info);
	
		$url = 'https://tiqs.com/alfred/Api/ScannerApiV2/VendorEvents';
		$args = array(
			'sslverify' => true,
			'timeout'   => 10,
			'headers'   => array(
				'Content-Type' => 'application/json'
			),
			'body'      => $data,
		);
	
		$response = wp_remote_post($url, $args);
	
		if (is_wp_error($response)) {
			return null;
		}
	
		$body = wp_remote_retrieve_body($response);
		$decoded_response = json_decode($body);
	
		return $decoded_response;
	}

	public function add_custom_query_var($query_vars) {
        $query_vars[] = 'event';
        return $query_vars;
    }

	public function include_files() {
        require_once TOED_EVENTROOTDIR . 'events-list.php';
        require_once TOED_EVENTROOTDIR . 'events-create.php';
        require_once TOED_EVENTROOTDIR . 'events-update.php';
        require_once TOED_EVENTROOTDIR . 'events-block.php';
        require_once TOED_EVENTROOTDIR . 'events-front-side.php';
        require_once TOED_EVENTROOTDIR . 'update-event-tags.php';
    }
}






// add_action('wp_head', 'add_custom_style');
// add_action('wp_ajax_update_status_db', 'update_status_db_callback');
// define('EVENTROOTDIR', plugin_dir_path(__FILE__));


// Instantiate the plugin
new EventsPlugin();