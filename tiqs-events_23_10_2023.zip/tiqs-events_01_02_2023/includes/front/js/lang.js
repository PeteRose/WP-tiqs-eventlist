// Day
var word_day_sun = 'Sunday';
var word_day_mon = 'Monday';
var word_day_tue = 'Tuesday';
var word_day_wed = 'Wednesday';
var word_day_thu = 'Thursday';
var word_day_fri = 'Friday';
var word_day_sat = 'Saturday';

// Month
var word_month_1 = 'January';
var word_month_2 = 'February';
var word_month_3 = 'March';
var word_month_4 = 'April';
var word_month_5 = 'May';
var word_month_6 = 'June';
var word_month_7 = 'July';
var word_month_8 = 'August';
var word_month_9 = 'September';
var word_month_10 = 'October';
var word_month_11 = 'November';
var word_month_12 = 'December';