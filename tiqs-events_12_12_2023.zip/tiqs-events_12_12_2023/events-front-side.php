<?php

namespace Tiqs_Events;

class EventsFrontSide
{
	public function tiqs_events_info_short_code()
	{
		ob_start();

		$html = '
			<span class="event-tiqs-wrapper">
				<div class="mw-100">
					<div class="preloader">
						<div id="circle-square">
							<span></span>
							<span></span>
							<span></span>
							<span></span>
						</div>
					</div>

					<main class="">
						<section class="section" id="full-calendar">
							<div class="container">
								<h2 class="section-title">Full Calendar</h2>
								<div class="section-body">
									<div class="quick-events" data-start="sunday"></div>
								</div>
							</div>
						</section>

						<section class="section" id="compact-calendar">
							<div class="container">
								<h2 class="section-title">Compact Calendar</h2>
								<div class="section-body">
									<div class="row">
										<div class="col-xl-8 col-lg-6 col-md-12">
											<div class="block-intro">
												<h3 class="title">Our Events</h3>
												<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit.ipsum, fuga, in, obcaecati magni Reprehenderit ullam nobis voluptas fugiat tenetur quas tempora maxime rerum neque deserunt suscipit provident cumque et mollitia.</p>
												<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit.ipsum, fuga, in, obcaecati magni Reprehenderit ullam nobis voluptas fugiat tenetur quas tempora maxime rerum neque deserunt suscipit provident cumque et mollitia.</p>
												<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit.ipsum, fuga, in, obcaecati magni Reprehenderit ullam nobis voluptas fugiat tenetur quas tempora maxime rerum neque deserunt suscipit provident cumque et mollitia.</p>
											</div>
										</div>
										<div class="' . ((!(get_option('tiqs_events_full_width') !== false && get_option('tiqs_events_full_width') == '')) ?
			"col-xl-4 col-lg-6 col-md-12" : "col-md-12") . '">
											<div class="quick-events" data-layout="compact"></div>
										</div>
									</div>
								</div>
							</div>
						</section>

						<section class="section" id="events-list">
							<div class="container">
								<h2 class="section-title">Events List</h2>
								<div class="section-body">
									<div class="quick-events" data-view="list" data-items="4"></div>
								</div>
							</div>
						</section>

						<section class="section" id="events-grid">
							<div class="container">
								<h2 class="section-title">Events Grid</h2>
								<div class="section-body">
									<div class="quick-events" data-view="grid"></div>
								</div>
							</div>
						</section>
					</main>

					<a class="back-to-top"><i class="icon-arrow-up"></i></a>
				</div>
			</span>
		';

		echo wp_kses_post($html);

		return ob_get_clean();
	}

	public function tiqs_event_calendar()
	{
		ob_start();

		$html = '
			<div class="mw-100">
				<main class="">
					<section class="section" id="full-calendar">
						<div class="container">
							<h2 class="section-title">Full Calendar</h2>
							<div class="section-body">
								<div class="quick-events" data-start="sunday"></div>
							</div>
						</div>
					</section>
				</main>
			</div>
		';

		echo wp_kses_post($html);

		return ob_get_clean();
	}

	public function tiqs_event_rows()
	{
		ob_start();

		$html = '
			<div class="mw-100">
				<main class="">
					<section class="section" id="events-list">
						<div class="container">
							<h2 class="section-title">Events List</h2>
							<div class="section-body">
								<div class="quick-events" data-view="list" data-items="4"></div>
							</div>
						</div>
					</section>
				</main>
			</div>
		';

		echo wp_kses_post($html);

		return ob_get_clean();
	}

	public function tiqs_event_cards()
	{
		ob_start();

		$html = '
			<div class="mw-100">
				<main class="">
					<section class="section" id="events-grid">
						<div class="container">
							<h2 class="section-title">Events Grid</h2>
							<div class="section-body">
								<div class="quick-events" data-view="grid"></div>
							</div>
						</div>
					</section>
				</main>
			</div>
		';

		echo wp_kses_post($html);

		return ob_get_clean();
	}

	public function tiqs_event_descript_calendar()
	{
		ob_start();

		$html = '
			<div class="mw-100">
				<main class="">
					<section class="section" id="compact-calendar">
						<div class="container">
							<h2 class="section-title">Compact Calendar</h2>
							<div class="section-body">
								<div class="row">
									<div class="col-xl-8 col-lg-6 col-md-12">
										<div class="block-intro">
											<h3 class="title">Our Events</h3>
											<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit.ipsum, fuga, in, obcaecati magni Reprehenderit ullam nobis voluptas fugiat tenetur quas tempora maxime rerum neque deserunt suscipit provident cumque et mollitia.</p>
											<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit.ipsum, fuga, in, obcaecati magni Reprehenderit ullam nobis voluptas fugiat tenetur quas tempora maxime rerum neque deserunt suscipit provident cumque et mollitia.</p>
											<p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit.ipsum, fuga, in, obcaecati magni Reprehenderit ullam nobis voluptas fugiat tenetur quas tempora maxime rerum neque deserunt suscipit provident cumque et mollitia.</p>
										</div>
									</div>
									<div class="' . ((!(get_option('tiqs_events_full_width') !== false && get_option('tiqs_events_full_width') == '')) ?
			"col-xl-4 col-lg-6 col-md-12" : "col-md-12") . '">
										<div class="quick-events" data-layout="compact"></div>
									</div>
								</div>
							</div>
						</div>
					</section>
				</main>
			</div>
		';

		echo wp_kses_post($html);

		return ob_get_clean();
	}

	public function get_file_url($path = '')
	{

		$url = plugins_url($path, __FILE__);

		if (
			is_ssl()
			and 'http:' == substr($url, 0, 5)
		) {
			$url = 'https:' . substr($url, 5);
		}

		return $url;
	}

	public function getAllEvents()
	{
		global $wpdb;
		$table_name = $wpdb->prefix . "tiqs_events";

		$rows = $wpdb->get_results("SELECT * from $table_name where type = 'manual' AND is_blocked = '0' AND vendorId=" . get_option('tiqs_events_info'));

		$blockedApiEvents = $wpdb->get_results("SELECT GROUP_CONCAT(event_id) AS 'eventId' FROM $table_name WHERE type = 'api' AND is_blocked = '1' AND vendorId=" . get_option('tiqs_events_info'));

		$blockedApiEvents = isset($blockedApiEvents[0]->eventId) ? $HiddenProducts = explode(',', $blockedApiEvents[0]->eventId) : array();

		$apiEventsUpdates = $wpdb->get_results("SELECT event_id, vendorId,tag FROM $table_name WHERE type = 'api' AND tag != '' AND tag IS NOT NULL AND vendorId=" . get_option('tiqs_events_info'));

		$events_plugin = new \Tiqs_Events\EventsPlugin();
		$events = $events_plugin->get_api_events();

		$allEvents = array();
		foreach ($rows as $rKey => $rValue) {
			$obj = new stdClass();
			$obj->color = "3";
			$obj->title = $rValue->eventname;
			$obj->description = $rValue->eventdescript;
			$obj->duration = "1";
			$obj->location = $rValue->eventAddress . ', ' . $rValue->eventCity . ', ' . $rValue->eventCountry;
			$obj->time = date("H:i", strtotime($rValue->StartTime)) . ' - ' . date("H:i", strtotime($rValue->EndTime));
			$obj->day = date("d", strtotime($rValue->StartDate));
			$obj->month = date("m", strtotime($rValue->StartDate));
			$obj->year = date("Y", strtotime($rValue->StartDate));
			$obj->image = $rValue->eventImage;
			$obj->id = $rValue->id;
			$obj->type = $rValue->type;
			$obj->facebookUrl = $rValue->facebookUrl;

			if (get_option('tiqs_events_popup_details') !== false && get_option('tiqs_events_popup_details') == '') {
				$obj->detailLink = '/event-detail?event=m-' . $rValue->id;
			}

			$link = $rValue->url;

			if ($rValue->tag) {
				$link .= '?tag=' . $rValue->tag;
			}

			if (get_option('tiqs_events_affiliate')) {
				if ($rValue->tag) {
					$link .= '&';
				} else {
					$link .= '?';
				}
				$link .= 'AMB=' . get_option('tiqs_events_affiliate');
			}

			$obj->link = $link;

			array_push($allEvents, $obj);
		}

		foreach ($events as $key => $value) {
			if (!in_array($value->id, $blockedApiEvents)) {
				$obj = new stdClass();
				$obj->color = "3";
				$obj->title = $value->eventname;
				$obj->description = $value->eventdescript;
				$obj->duration = "1";
				$obj->location = $value->eventAddress . ', ' . $value->eventCity . ', ' . $value->eventCountry;
				$obj->time = date("H:i", strtotime($value->StartTime)) . ' - ' . date("H:i", strtotime($value->EndTime));
				$obj->day = date("d", strtotime($value->StartDate));
				$obj->month = date("m", strtotime($value->StartDate));
				$obj->year = date("Y", strtotime($value->StartDate));
				$obj->image = 'https://tiqs.com/alfred/assets/images/events/' . $value->eventImage;
				$obj->event_id = $value->id;
				$obj->type = 'api';
				$obj->facebookUrl = $value->facebookUrl;
				$obj->amb = get_option('tiqs_events_affiliate');

				if (get_option('tiqs_events_popup_details') !== false && get_option('tiqs_events_popup_details') == '') {
					$obj->detailLink = '/event-detail?event=a-' . $value->id;
				}

				$search = $value->id;
				$isDataExist = array_filter($apiEventsUpdates, function ($item) use ($search) {
					return $item->event_id == $search;
				});

				$tag = isset($isDataExist[array_key_first($isDataExist)]->tag) ? $isDataExist[array_key_first($isDataExist)]->tag : '';

				// $link = 'http://tiqs.com/alfred/events/shop/' . $value->id;
				$link = $value->redirectShopUrl && checkShopStatus($value->id) ? $value->redirectShopUrl : ('http://tiqs.com/alfred/events/shop/' . $value->id);

				if ($tag) {
					$link .= '?tag=' . $tag;
				}

				if (get_option('tiqs_events_affiliate')) {
					if ($tag) {
						$link .= '&';
					} else {
						$link .= '?';
					}
					$link .= 'AMB=' . get_option('tiqs_events_affiliate');
				}

				$obj->link = $link;

				array_push($allEvents, $obj);
			}
		}

		return $allEvents;
	}

	public function get_all_events()
	{
		global $wpdb;
		$table_name = $wpdb->prefix . "tiqs_events";

		$rows = [];
		$blockedApiEvents = [];
		$apiEventsUpdates = [];

		if (get_option('tiqs_events_info')) {

			$rows = $wpdb->get_results($wpdb->prepare("SELECT * from $table_name where type = 'manual' AND is_blocked = '0' AND vendorId=%s", get_option('tiqs_events_info')));

			$blockedApiEvents = $wpdb->get_results($wpdb->prepare("SELECT GROUP_CONCAT(event_id) AS 'eventId' FROM $table_name WHERE type = 'api' AND is_blocked = '1' AND vendorId=%s", get_option('tiqs_events_info')));

			$blockedApiEvents = isset($blockedApiEvents[0]->eventId) ? $HiddenProducts = explode(',', $blockedApiEvents[0]->eventId) : array();

			$apiEventsUpdates = $wpdb->get_results($wpdb->prepare("SELECT event_id, vendorId,tag FROM $table_name WHERE type = 'api' AND tag != '' AND tag IS NOT NULL AND vendorId=%s", get_option('tiqs_events_info')));
		}

		$events_plugin = new \Tiqs_Events\EventsPlugin();
		$events = $events_plugin->get_api_events();

		$allEvents = array();
		foreach ($rows as $rKey => $rValue) {
			$obj = new \stdClass();
			$obj->color = "3";
			$obj->title = $rValue->eventname;
			$obj->description = $rValue->eventdescript;
			$obj->duration = "1";
			$obj->location = $rValue->eventAddress . ', ' . $rValue->eventCity . ', ' . $rValue->eventCountry;
			$obj->time = date("H:i", strtotime($rValue->StartTime)) . ' - ' . date("H:i", strtotime($rValue->EndTime));
			$obj->starttime = date("H:i", strtotime($rValue->StartTime));
			$obj->endtime = date("H:i", strtotime($rValue->EndTime));
			$obj->startdate = $rValue->StartDate;
			$obj->day = date("d", strtotime($rValue->StartDate));
			$obj->startdayname = date("D", strtotime($rValue->StartDate));
			$obj->month = date("m", strtotime($rValue->StartDate));
			$obj->startmonthname = date("M", strtotime($rValue->StartDate));
			$obj->year = date("Y", strtotime($rValue->StartDate));
			$obj->enddate = date("d-m-Y", strtotime($rValue->EndDate));
			$obj->image = $rValue->eventImage;
			$obj->id = $rValue->id;
			$obj->type = $rValue->type;
			$obj->facebookUrl = $rValue->facebookUrl;
			$link = $rValue->url;

			if ($rValue->tag) {
				$link .= '?tag=' . $rValue->tag;
			}

			if (get_option('tiqs_events_affiliate')) {
				if ($rValue->tag) {
					$link .= '&';
				} else {
					$link .= '?';
				}
				$link .= 'AMB=' . get_option('tiqs_events_affiliate');
			}

			$obj->link = $link;

			array_push($allEvents, $obj);
		}
		if (isset($events) && (is_array($events) || is_object($events))) {
			foreach ($events as $key => $value) {
				if (!in_array($value->id, $blockedApiEvents)) {
					$obj = new \stdClass();
					$obj->color = "3";
					$obj->title = $value->eventname;
					$obj->description = $value->eventdescript;
					$obj->duration = "1";
					$obj->location = $value->eventAddress . ', ' . $value->eventCity . ', ' . $value->eventCountry;
					$obj->time = date("H:i", strtotime($value->StartTime)) . ' - ' . date("H:i", strtotime($value->EndTime));
					$obj->starttime = date("H:i", strtotime($value->StartTime));
					$obj->endtime = date("H:i", strtotime($value->EndTime));
					$obj->startdate = $value->StartDate;
					$obj->day = date("d", strtotime($value->StartDate));
					$obj->startdayname = date("D", strtotime($value->StartDate));
					$obj->month = date("m", strtotime($value->StartDate));
					$obj->startmonthname = date("M", strtotime($value->StartDate));
					$obj->year = date("Y", strtotime($value->StartDate));
					$obj->enddate = date("d-m-Y", strtotime($value->EndDate));
					$obj->image = 'https://tiqs.com/alfred/assets/images/events/' . $value->eventImage;
					$obj->event_id = $value->id;
					$obj->type = 'api';
					$obj->facebookUrl = $value->facebookUrl;
					$obj->amb = get_option('tiqs_events_affiliate');

					$search = $value->id;
					$isDataExist = array_filter($apiEventsUpdates, function ($item) use ($search) {
						return $item->event_id == $search;
					});

					$tag = isset($isDataExist[array_key_first($isDataExist)]->tag) ? $isDataExist[array_key_first($isDataExist)]->tag : '';


					$link = $value->redirectShopUrl && $this->check_shop_status($value->id) ? $value->redirectShopUrl : ('http://tiqs.com/alfred/events/shop/' . $value->id);

					if ($tag) {
						$link .= '?tag=' . $tag;
					}

					if (get_option('tiqs_events_affiliate')) {
						if ($tag) {
							$link .= '&';
						} else {
							$link .= '?';
						}
						$link .= 'AMB=' . get_option('tiqs_events_affiliate');
					}

					$obj->link = $link;

					array_push($allEvents, $obj);
				}
			}
		}

		return $allEvents;
	}

	public function check_shop_status($eventId)
	{
		$body = array('eventId' => $eventId);
		$data = array(
			'body'	=> $body
		);
		$response = wp_remote_post('https://tiqs.com/alfred/Api/Eventsnew/check_active_shop', $data);
		$resp     = wp_remote_retrieve_body($response);

		$records = json_decode($resp);

		if (isset($records->status) && $records->status == 1) {
			return true;
		}
		return false;
	}

	public static function tiqs_events_header()
	{
		global $post;

		if (has_shortcode($post->post_content, 'tiqs-events') || has_shortcode($post->post_content, 'tiqs-event-calendar') || has_shortcode($post->post_content, 'tiqs-event-rows') || has_shortcode($post->post_content, 'tiqs-event-cards') || has_shortcode($post->post_content, 'tiqs-event-descript-calendar')) {

			wp_enqueue_style('tiqs-events-1', plugins_url('includes/front/css/simple-line-icons.css', __FILE__));
			wp_enqueue_style('tiqs-events-2', plugins_url('includes/front/css/magnific-popup.css', __FILE__));
			wp_enqueue_style('tiqs-events-3', plugins_url('includes/front/css/quick-events.css', __FILE__));
			wp_enqueue_style('tiqs-events-4', 'https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i&display=swap&subset=cyrillic');
			wp_enqueue_style('tiqs-events-5', plugins_url('includes/front/css/bootstrap.min.css', __FILE__));
			wp_enqueue_style('tiqs-events-6', plugins_url('includes/front/css/demo.css', __FILE__));

			wp_enqueue_script('tiqs-events-script-1', plugins_url('includes/front/js/lang.js', __FILE__), array('jquery'));
			wp_enqueue_script('tiqs-events-script-2', plugins_url('includes/front/js/jquery.magnific-popup.js', __FILE__), array('jquery'));
			wp_enqueue_script('tiqs-events-script-3', plugins_url('includes/front/js/quick-events.js', __FILE__), array('jquery'));
			wp_enqueue_script('tiqs-events-script-4', plugins_url('includes/front/js/bootstrap.min.js', __FILE__), array('jquery'));
			wp_enqueue_script('tiqs-events-script-5', plugins_url('includes/front/js/demo.js', __FILE__), array('jquery'));

			$instance = new \Tiqs_Events\EventsFrontSide();
			wp_localize_script('tiqs-events-script-4', 'tiqsEvents', $instance->get_all_events());


?>
			<style>
				<?php if (get_option('tiqs_events_primary_color')) { ?>.event-tiqs-wrapper .preloader #circle-square span {
					background-color: <?php echo get_option('tiqs_events_primary_color') ?>;
				}

				.event-tiqs-wrapper .section-title:after {
					background: <?php echo get_option('tiqs_events_primary_color') ?>;
				}

				.event-tiqs-wrapper .back-to-top:hover {
					background: <?php echo get_option('tiqs_events_primary_color') ?>;
				}

				.quick-events .events-calendar .calendar-header .current-date span {
					color: <?php echo get_option('tiqs_events_primary_color') ?>;
				}

				.quick-events .events-calendar .calendar-header .nav-time .btn-change-date {
					border: 1px solid <?php echo get_option('tiqs_events_primary_color') ?>;
					background: <?php echo get_option('tiqs_events_primary_color') ?>;
				}

				.quick-events .events-calendar .calendar-table .calendar-day.weekend .day-num {
					color: <?php echo get_option('tiqs_events_primary_color') ?>;
				}

				.quick-events .events-calendar .calendar-table .calendar-day.today .day-num {
					background: <?php echo get_option('tiqs_events_primary_color') ?>;
				}

				.quick-events .events-calendar .calendar-table .calendar-day .event-title.color-2 {
					background: <?php echo get_option('tiqs_events_primary_color') ?>;
				}

				.quick-events .events-calendar.compact .calendar-table .calendar-day .event-mark.color-2 {
					background: <?php echo get_option('tiqs_events_primary_color') ?>;
				}

				.event-tiqs-wrapper .btn.custom-btn-primary {
					background: <?php echo get_option('tiqs_events_primary_color') ?>;
				}

				.event-tiqs-wrapper .btn.custom-btn-primary:hover {
					background: <?php echo get_option('tiqs_events_primary_color') ?>;
				}

				<?php }
				if (get_option('tiqs_events_secondary_color')) {
				?>@-webkit-keyframes preloader_2_1 {
					0% {
						-webkit-transform: translateX(0) translateY(0) rotate(0);
						transform: translateX(0) translateY(0) rotate(0);
						border-radius: 0;
					}

					50% {
						-webkit-transform: translateX(-20px) translateY(-10px) rotate(-180deg);
						transform: translateX(-20px) translateY(-10px) rotate(-180deg);
						border-radius: 50%;
						background: <?php echo get_option('tiqs_events_secondary_color') ?>;
					}

					100%,
					80% {
						-webkit-transform: translateX(0) translateY(0) rotate(-360deg);
						transform: translateX(0) translateY(0) rotate(-360deg);
						border-radius: 0;
					}
				}

				@keyframes preloader_2_1 {
					0% {
						-webkit-transform: translateX(0) translateY(0) rotate(0);
						transform: translateX(0) translateY(0) rotate(0);
						border-radius: 0;
					}

					50% {
						-webkit-transform: translateX(-20px) translateY(-10px) rotate(-180deg);
						transform: translateX(-20px) translateY(-10px) rotate(-180deg);
						border-radius: 50%;
						background: <?php echo get_option('tiqs_events_secondary_color') ?>;
					}

					100%,
					80% {
						-webkit-transform: translateX(0) translateY(0) rotate(-360deg);
						transform: translateX(0) translateY(0) rotate(-360deg);
						border-radius: 0;
					}
				}

				.quick-events .events-calendar .calendar-table .calendar-day .event-title.color-3 {
					background: <?php echo get_option('tiqs_events_secondary_color') ?>;
				}

				.quick-events .events-calendar.compact .calendar-table .calendar-day .event-mark.color-3 {
					background: <?php echo get_option('tiqs_events_secondary_color') ?>;
				}

				<?php }
				if (get_option('tiqs_events_radius_cards') && get_option('tiqs_events_radius_cards') !== 'true') {
				?>.quick-events .events-calendar {
					-webkit-border-radius: <?php echo get_option('tiqs_events_radius_cards') ?>px !important;
					-moz-border-radius: <?php echo get_option('tiqs_events_radius_cards') ?>px !important;
					border-radius: <?php echo get_option('tiqs_events_radius_cards') ?>px !important;
				}

				.quick-events .events-list .event-item {
					-webkit-border-radius: <?php echo get_option('tiqs_events_radius_cards') ?>px !important;
					-moz-border-radius: <?php echo get_option('tiqs_events_radius_cards') ?>px !important;
					border-radius: <?php echo get_option('tiqs_events_radius_cards') ?>px !important;
				}

				<?php }
				if (get_option('tiqs_events_radius_images') && get_option('tiqs_events_radius_images') !== 'true') {
				?>.quick-events .events-list .event-item .event-image img {
					border-radius: <?php echo get_option('tiqs_events_radius_images') ?>px !important;
				}

				<?php }
				if (get_option('tiqs_events_font_color')) {
				?>.event-tiqs-wrapper * {
					color: <?php echo get_option('tiqs_events_font_color') ?>;
				}

				<?php }
				if (get_option('tiqs_events_heading_color')) {
				?>.event-tiqs-wrapper h1,
				.event-tiqs-wrapper h2,
				.event-tiqs-wrapper h3,
				.event-tiqs-wrapper h4,
				.event-tiqs-wrapper h5,
				.event-tiqs-wrapper h6 {
					color: <?php echo get_option('tiqs_events_heading_color') ?> !important;
				}

				<?php } ?>
			</style>
<?php }
	}

	// public static function tiqs_events_footer_js()
	// {
	// 	global $post;

	// 	if (has_shortcode($post->post_content, 'tiqs-events') || has_shortcode($post->post_content, 'tiqs-event-calendar') || has_shortcode($post->post_content, 'tiqs-event-rows') || has_shortcode($post->post_content, 'tiqs-event-cards') || has_shortcode($post->post_content, 'tiqs-event-descript-calendar')) {
	// 		wp_enqueue_style('tiqs-events-1', plugins_url('includes/front/css/simple-line-icons.css', __FILE__));
	// 		wp_enqueue_style('tiqs-events-2', plugins_url('includes/front/css/magnific-popup.css', __FILE__));
	// 		wp_enqueue_style('tiqs-events-3', plugins_url('includes/front/css/quick-events.css', __FILE__));
	// 		wp_enqueue_style('tiqs-events-4', 'https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i&display=swap&subset=cyrillic');
	// 		wp_enqueue_style('tiqs-events-5', plugins_url('includes/front/css/bootstrap.min.css', __FILE__));
	// 		wp_enqueue_style('tiqs-events-6', plugins_url('includes/front/css/demo.css', __FILE__));

	// 		wp_enqueue_script('tiqs-events-script-1', plugins_url('includes/front/js/lang.js', __FILE__), array('jquery'));
	// 		wp_enqueue_script('tiqs-events-script-2', plugins_url('includes/front/js/jquery.magnific-popup.js', __FILE__), array('jquery'));
	// 		wp_enqueue_script('tiqs-events-script-3', plugins_url('includes/front/js/quick-events.js', __FILE__), array('jquery'));
	// 		wp_enqueue_script('tiqs-events-script-4', plugins_url('includes/front/js/bootstrap.min.js', __FILE__), array('jquery'));
	// 		wp_enqueue_script('tiqs-events-script-5', plugins_url('includes/front/js/demo.js', __FILE__), array('jquery'));

	// 		// Make sure to enqueue the script you're trying to localize.
	// 		wp_enqueue_script('tiqs-events-local-script', '', array('jquery'));
	// 		wp_localize_script('tiqs-events-local-script', 'tiqsEvents', $this->get_all_events());
	// 	}
	// }
}
